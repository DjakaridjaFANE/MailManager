import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;

import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.Message.RecipientType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.sun.net.httpserver.HttpServer;

import Objet.Compte;
import Objet.Mail;

public class Reseau {


	//----------------------------------------------------------   IMAP   -----------------------------------------------------------------------------------
	//Chemin d'acces au pieces_jointes
	private static final String PATH_DU_FICHIER = "E:\\Workspace\\MailTest\\reception";

	//Liste des serveur POP en fonction du service 
	private static final String[][] SERVEUR_IMAP= {
			{"outlook","outlook.office365.com"},
			{"gmail","imap.gmail.com"},
			{"univ-rennes1","z883.zimbra.io"}
	};


	/*
	 * @param compte dont l'on souhaite de r�cup�rer les mails
	 * @return  mails r�cup�rer
	 */
	public static ArrayList<Mail> synchronisation(Compte compte) throws MessagingException, IOException {
		ArrayList<Mail> mails = new ArrayList<Mail>();
		for(Map.Entry<Address, String> valeur : compte.getComptes().entrySet() ) {
			// On recherche en fonction de l'adresse quel serveur POP utiliser
			String imap_host = null;
			for(int j = 0 ; j < SERVEUR_IMAP.length; j++) {

				if(valeur.getKey().toString().contains(SERVEUR_IMAP[j][0])) {
					imap_host= SERVEUR_IMAP[j][1];
				}
			}

			String motDePasse = valeur.getValue();
			String ident = valeur.getKey().toString() ;
			Address addr = valeur.getKey();
			// On fait l'authentification 
			Authenticator auth = new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(addr.toString(), motDePasse);
				}

			};
			//On ajout les propri�t�s
			Properties proprietes = new Properties();
			proprietes.put("mail.store.protocol", "imaps");
			proprietes.put("mail.imap.host", imap_host);
			proprietes.put("mail.imap.ssl.enable", true);
			proprietes.put("mail.imap.port","993");
			proprietes.put( "mail.imap.socketFactory.port", "993");

			Session session = Session.getInstance(proprietes , auth);
			Store store = null;
			Folder dossierParDefault = null;
			Folder boiteDeReception = null;

			store = session.getStore("imap");
			store.connect(imap_host, ident, motDePasse);		
			dossierParDefault = store.getDefaultFolder();
			boiteDeReception = dossierParDefault.getFolder("INBOX");
			if(boiteDeReception.getMessageCount() > 0)
				mails.addAll( traitement(boiteDeReception));
			for (Folder dossier : dossierParDefault.list()) {
				//TODO probleme sur le type
				if(dossier.getType() == 3 && dossier.getMessageCount() > 0)
					mails.addAll( traitement(dossier));
			}


			//Si des dossiers sont ouvert alors on les ferme 
			if (boiteDeReception != null && boiteDeReception.isOpen())
				boiteDeReception.close();
			if (dossierParDefault != null && dossierParDefault.isOpen())
				dossierParDefault.close();
			if (store != null && store.isConnected()) {
				store.close();
			}


		}
		return mails;
	}


	/**
	 * 
	 * @param boite est un dossier qui contient des mails
	 * @return un tableau avec les mails pr�sent dans le dossier/la boite
	 * @throws MessagingException 
	 * @throws IOException 
	 */
	private static ArrayList<Mail> traitement(Folder boite) throws IOException, MessagingException{
		//On initialise le tableau de retour
		ArrayList<Mail> retour =new ArrayList<Mail>();

		//On ouvre la boite en lecture
		boite.open(Folder.READ_WRITE);
		for(int i = 1 ; i < boite.getMessageCount() ; i++) {
			//On r�cup�re le message d'occurence i et on r�cup�re ses informations
			Message message = boite.getMessage(i);
			String objet = message.getSubject();
			Date date = new Date(message.getSentDate().getTime());
			Address expediteur = new InternetAddress(message.getFrom()[0].toString());
			ArrayList<Address> destinataire = new ArrayList<Address>(Arrays.asList(message.getRecipients(RecipientType.TO)));

			Address[] ccArray = message.getRecipients(RecipientType.CC);
			ArrayList<Address> cc = new ArrayList<Address>(Arrays.asList((ccArray == null)? new Address[0]: ccArray));

			Address[] cciArray = message.getRecipients(RecipientType.CC);
			ArrayList<Address> cci = new ArrayList<Address>(Arrays.asList((cciArray == null)? new Address[0]: cciArray));

			ArrayList<String> listePiecesJointes = new ArrayList<String>();
			String contenu ="";
			// Si pieces jointes alors on ouvre le message d'une certaines fa�ons
			if(message.getContentType().contains("multipart/")) {
				DataSource dataSource = message.getDataHandler().getDataSource();
				MimeMultipart mimeMultipart = new MimeMultipart(dataSource);
				//On traite chaque partie dans le mssage si c'est du text alors on le met dans contenu 
				for(int j = 0 ; j < mimeMultipart.getCount(); j++) {
					if(mimeMultipart.getBodyPart(j).isMimeType("text/plain")) {
						char[] buffer = new char[mimeMultipart.getBodyPart(j).getSize()];

						InputStreamReader isr = new InputStreamReader(mimeMultipart.getBodyPart(j).getInputStream());
						isr.read(buffer);
						for(int z = 0 ; z < buffer.length; z++) {
							contenu = contenu +buffer[z];
						}

					}
					//Sinon on cr�e un fichier dans un dossier 
					else {
						File fichier = new File(PATH_DU_FICHIER + "/received_" + mimeMultipart.getBodyPart(j).getFileName());
						FileOutputStream fos;


						fos = new FileOutputStream(fichier);
						mimeMultipart.getBodyPart(j).writeTo(fos);

						//et on ajoute le path du fichier dans notre tableau des pieces jointes
						listePiecesJointes.add(PATH_DU_FICHIER + "/received_" + mimeMultipart.getBodyPart(j).getFileName());				            
					}

				}

			}
			else { //Sinon on r�cup�re juste le contenu 
				String content = null;

				content = (String) message.getContent();

				char[] buffer = new char[content.length()];
				InputStreamReader isr;

				isr = new InputStreamReader(message.getInputStream());
				isr.read(buffer);
				for(char lettre : buffer) {
					contenu = contenu + lettre;
				}



			}
			//Puis on ajoute toutes les informations r�cup�rer
			retour.add(new Mail(expediteur, destinataire, cc, cci, objet, listePiecesJointes, date,  contenu));
			//message.setFlag(Flags.Flag.DELETED, true);
		}


		return retour;

	}
	//----------------------------------------------------------   SMTP   -----------------------------------------------------------------------------------
	//Serveur SMTP en fonction du service
	private static final String[][] SERVEUR_SMTP= {
			{"outlook","smtp-mail.outlook.com"},
			{"gmail","smtp.gmail.com"},
			{"univ-rennes1","z883.zimbra.io"}
	};
	//Port tls
	private final static int PORT_TLS = 587;

	/*
	 * @param mail L'email � envoyer
	 * @param compte Le compte qui envoie l'email 
	 * @return return true si le mail est envoy� 
	 */
	public static boolean envoieMail(Mail mail , Compte compte) throws MessagingException {

		String motDePasse = null;
		//On v�rifie que l'adresse expediteur soit bien une adresse enregistr� dans le compte et on r�cup�re son mdp 
		for(Map.Entry<Address, String> valeur : compte.getComptes().entrySet()) {
			if(valeur.getKey().toString().equals(mail.getExpediteur().toString()))
				motDePasse = valeur.getValue();
		}
		//Si on a pas le mdp on ne peut pas envoyer un mail
		if(motDePasse == null)
			return false;
		//On fait l'authentification 
		Authenticator auth = new Authenticator() { //Authentification 
			protected PasswordAuthentication getPasswordAuthentication() {
				for(Map.Entry<Address, String> valeur : compte.getComptes().entrySet()) {
					if(valeur.getKey().toString().equals(mail.getExpediteur().toString()))
						return new PasswordAuthentication(mail.getExpediteur().toString(),valeur.getValue());
				}
				return null;
			}
		};

		//On rentre les propri�t�s 
		Properties proprietes = new Properties();
		String smtpHost = null;
		for(int j = 0 ; j < SERVEUR_SMTP.length; j++) {
			if(mail.getExpediteur().toString().contains(SERVEUR_SMTP[j][0]))
				smtpHost= SERVEUR_SMTP[j][1];
		}
		if(smtpHost == null)
			return false;
		proprietes.put("mail.smtp.host", smtpHost);
		proprietes.put("mail.smtp.port", PORT_TLS);
		proprietes.put("mail.smtp.auth", "true");
		proprietes.put("mail.smtp.starttls.enable", "true");	
		//On cr�e la sessions
		Session session = Session.getInstance(proprietes, auth);


		MimeMessage message = new MimeMessage(session); // En t�te du mail
		Multipart multipart = new MimeMultipart(); // Pieces jointes et contenu
		BodyPart messageBodyPart = new MimeBodyPart();

			//On rempli l'entete du message 
			message.setText(mail.getContenu());
			message.setSubject(mail.getObjet());
			message.setFrom(mail.getExpediteur());
			InternetAddress[] adressesReponse = {new InternetAddress(mail.getExpediteur().toString())};
			message.setReplyTo(adressesReponse); //TODO Temporaire peut �tre un ajout de pouvoir modifier les addresses de r�ponses
			message.addRecipients(Message.RecipientType.TO,  mail.getDestinataire().toArray(new Address[mail.getDestinataire().size()]));
			message.addRecipients(Message.RecipientType.CC,  mail.getCC().toArray(new Address[mail.getCC().size()]));
			message.addRecipients(Message.RecipientType.BCC,  mail.getCCI().toArray(new Address[mail.getCCI().size()]));
			message.setSentDate(mail.getDate());
			//On rempli le contenu du mail avec ses pieces jointes
			messageBodyPart.setText(mail.getContenu());
			multipart.addBodyPart(messageBodyPart);
			int taille = (mail.getPiecesJointes() == null)? 0: mail.getPiecesJointes().size();

			for(int i = 0 ; i < taille ;i++) {
				messageBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(mail.getPiecesJointes().get(i));
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(source.getName());
				multipart.addBodyPart(messageBodyPart);
			}
			message.setContent(multipart);


		// On cr�e la connection et on envoie les mails aux destinataires , aux cc et aux cci
		Transport transport = null;                 
			transport = session.getTransport("smtp");
			transport.connect(mail.getExpediteur().toString().split("@")[0] ,motDePasse.replace("\n", ""));
			Transport.send(message, mail.getDestinataire().toArray(new Address[mail.getDestinataire().size()]));
			if(mail.getCC().size() > 0 )
				Transport.send(message, mail.getCC().toArray(new Address[mail.getCCI().size()]));
			if(mail.getCCI().size()> 0 )
				Transport.send(message, mail.getCCI().toArray(new Address[mail.getCCI().size()]));

			//Puis on ferme la connection

				if (transport != null) {
					transport.close();
					return false;
				}

		return true;
	}


	//----------------------------------------------------------   Requete   -----------------------------------------------------------------------------------



	public static HttpServer attenteRequete(BDD bdd) throws IOException {
		HttpServer server = null;

		server = HttpServer.create(new InetSocketAddress(8000), 0);
		server.createContext("/mailmanager", new CustomHandler(bdd));
		server.start();

		return server;
	}


	private static int i = 0;
	public static String simulationRequete() {

		try {
			if(i%2 == 0)
				Thread.sleep(15000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		i++;
		return "GET compte/ident:jbon/token:123456/id:" + i;
	}
}
