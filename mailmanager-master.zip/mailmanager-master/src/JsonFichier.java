import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import javax.mail.Address;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import Objet.Compte;
import Objet.Mail;

public class JsonFichier {
	
	//Chemin du fichier ou il y a les JSON
	private static final String PATH ="E:\\Workspace\\MailManager\\json";

	/*
	 * @param mails : listes des mails � mettre dans le json
	 * @param compte : compte qui cr�e le fichier json
	 */
	public static String jsonMail(ArrayList<Mail> mails , Compte compte) {

		//Creation du contenu du fichier JSON
		JSONArray tabMails = new JSONArray();
		for(Mail mail : mails) {
			JSONObject mailsJson = new JSONObject();
			mailsJson.put("expediteur", mail.getExpediteur().toString());
			mailsJson.put("objet", mail.getObjet());
			mailsJson.put("contenu", mail.getContenu());
			mailsJson.put("id", ""+mail.getId());
			mailsJson.put("date", mail.getDate().toString());

			JSONArray destinataire = new JSONArray();
			for(Address dest : mail.getDestinataire()) {
				destinataire.add(dest.toString());
			}
			JSONArray cc = new JSONArray();
			for(Address c : mail.getCC()) {
				cc.add(c.toString());
			}
			JSONArray cci = new JSONArray();
			for(Address ci : mail.getCCI()) {
				cci.add(ci.toString());
			}
			JSONArray pj = new JSONArray();
			if(mail.getPiecesJointes().size()>0)
			pj.addAll(Arrays.asList(mail.getPiecesJointes()));

			mailsJson.put("destinataires", destinataire);
			mailsJson.put("cc", cc);
			mailsJson.put("cci", cci);
			mailsJson.put("piecesJointes", pj);
			tabMails.add(mailsJson);
		}
		JSONObject json = new JSONObject();
		json.put("mails", tabMails);
		return json.toJSONString();
	}


	/*
	 * @param path : Chemin du fichier JSON � lire
	 */
	public static ArrayList<Mail> lireMailJson(String corp) {
		ArrayList<Mail> ret = new ArrayList<Mail>();
		Address expediteur = null;
		ArrayList<Address> destinataires = new ArrayList<Address>();
		ArrayList<Address> cc = new ArrayList<Address>();
		ArrayList<Address> cci = new ArrayList<Address>();
		ArrayList<String>  piecesJointes = new ArrayList<String>();
		String objet = "";
		String contenu = "";
		Date date = null;


		JSONParser jsonParseCouche0 = new JSONParser();	
		try {
			
			JSONObject jsonObjCouche0 = (JSONObject) jsonParseCouche0.parse(corp);			
			JSONArray jsonTabMails = (JSONArray) jsonObjCouche0.get("mails");
			JSONParser jsonParseCouche1;
			for(int i = 0 ;i < jsonTabMails.size() ; i++) {
				jsonParseCouche1= new JSONParser();
				JSONObject jsonObjCouche1 = (JSONObject) jsonParseCouche1.parse(jsonTabMails.get(i).toString());

				expediteur = new InternetAddress(jsonObjCouche1.get("expediteur").toString());
				objet = jsonObjCouche1.get("objet").toString();
				contenu = jsonObjCouche1.get("contenu").toString();
				date = Date.valueOf(jsonObjCouche1.get("date").toString());

				JSONArray jsonTabDestinataire = (JSONArray) jsonObjCouche1.get("destinataires");
				for(int j = 0 ; j < jsonTabDestinataire.size() ; j++) {
					destinataires.add(new InternetAddress(jsonTabDestinataire.get(j).toString()));
				}

				JSONArray jsonTabCc = (JSONArray) jsonObjCouche1.get("cc");
				for(int j = 0 ; j < jsonTabCc.size() ; j++) {
					cc.add(new InternetAddress(jsonTabCc.get(j).toString()));
				}

				JSONArray jsonTabCci = (JSONArray) jsonObjCouche1.get("cci");
				for(int j = 0 ; j < jsonTabCci.size() ; j++) {
					cci.add(new InternetAddress(jsonTabCci.get(j).toString()));
				}
				
				JSONArray jsonTabPiecesJointes = (JSONArray) jsonObjCouche1.get("piecesJointes");
				for(int j = 0 ; j < jsonTabPiecesJointes.size() ; j++) {
					piecesJointes.add(jsonTabPiecesJointes.get(j).toString());
				}				 
				ret.add(new Mail(0, expediteur , destinataires, cc, cci, objet, piecesJointes, (java.sql.Date) date, contenu));
			}

		
		} catch (ParseException | AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return ret;
	}

	/*
	 * @param compte : Compte � afficher dans le Json
	 */
	public static String jsonCompte(Compte compte) {
		JSONObject compteJson = new JSONObject();
		compteJson.put("identifiant", compte.getIdent());
		compteJson.put("nom", compte.getNom());
		compteJson.put("prenom", compte.getPrenom());
		compteJson.put("mdp", compte.getMdp());
		JSONArray adresses = new JSONArray();
		for(Map.Entry<Address, String> valeur : compte.getComptes().entrySet()) {
			JSONObject paire = new JSONObject();
			paire.put("adresse", valeur.getKey().toString());
			paire.put("mdp", valeur.getValue());
			adresses.add(paire);
		}
		compteJson.put("adresses", adresses);
		return compteJson.toJSONString();
	}
	
	/*
	 * @param path : Chemin du fichier JSON � lire
	 */
	public static Compte lireCompteJson(String corp) {
		Compte compte =null;
		JSONParser jsonParseCouche0 = new JSONParser();	
		String identifiant = null;
		String mdp = null;
		String nom = null;
		String prenom = null;

		try {
			JSONObject jsonObjCouche0 = (JSONObject) jsonParseCouche0.parse(corp);
			identifiant = jsonObjCouche0.get("identifiant").toString();
			nom = jsonObjCouche0.get("nom").toString();
			prenom = jsonObjCouche0.get("prenom").toString();
			mdp = jsonObjCouche0.get("mdp").toString();
			compte = new Compte(identifiant ,mdp ,nom ,prenom);
			
			JSONArray tabAdresses = (JSONArray) jsonObjCouche0.get("adresses");
			for(int i = 0 ; i < tabAdresses.size() ; i++) {
				JSONObject jsonObjCouche1 = (JSONObject) tabAdresses.get(i);
				compte.ajouteAddr(new InternetAddress(jsonObjCouche1.get("adresse").toString()), jsonObjCouche1.get("mdp").toString());

			}
		} catch (ParseException | AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return compte;
	}


	
	public static String jsonErreur(String erreur , String type) {
		JSONObject compteJson = new JSONObject();
		compteJson.put("type",type);
		compteJson.put("erreur",erreur);
		return	compteJson.toJSONString();
		}
}
