import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import javax.mail.Address;
import javax.mail.MessagingException;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import Objet.Compte;
import Objet.Mail;



class CustomHandler implements HttpHandler {

	private  BDD bdd;


	public CustomHandler( BDD bdd) {

		this.bdd = bdd;
	}

	private  String traitementRequete(HttpExchange exchange) {
		String reponse = "";

		String mode = exchange.getRequestMethod().toString();
		String url = exchange.getRequestURI().toString();
		String requete = url.split("\\?")[0];
		String parametresMalFormer = url.split("\\?")[1];

		String[] params =  parametresMalFormer.split("&");
		HashMap<String, String> parametres = new HashMap<String , String>();

		for(int i = 0 ; i < params.length ; i++) {
			String[ ] keyValue =  params[i].split(":");
			parametres.put(keyValue[0], keyValue[1]);

		}

		try {
			if( mode.equals("GET")) {

				if(requete.contains("mails")) {
					System.out.println("Mails");
					String ident = parametres.get("identifiant");
					String token = parametres.get("mdp");
					Compte compte = bdd.rechercheCompte(ident);

					ArrayList<Mail> mails = new ArrayList<Mail>();
					if(!bdd.connexion(ident, token)) {
						reponse = JsonFichier.jsonErreur("Erreur pas de compte avec l'identifiant : " + parametres.get("identifiant") + "ou ce mot de passe", "Not Fatal");
						return reponse;
					}
					Thread th = new Thread(){
						public void run(){
							try {
								ArrayList<Mail> mails_recu = Reseau.synchronisation(compte);
								for(Mail mail : mails_recu) {

									bdd.ajouteMail(mail);
								} 
							}catch (MessagingException | IOException | SQLException e) {
									e.printStackTrace();
							}		
					}};
					th.start();
					if(parametres.containsKey("id_mail")) {
						mails = new ArrayList<Mail>();
						mails.add(bdd.rechercheMail(stringToInt(parametres.get("id_mail"))));
					}
					else {
						for(Map.Entry<Address, String> valeur : compte.getComptes().entrySet()) {
							ArrayList<Address> val = new ArrayList<Address>();
							val.add(valeur.getKey());
							mails.addAll(bdd.rechercheMail(valeur.getKey() ,val , val , val));
						}
					}
					reponse = JsonFichier.jsonMail(mails, compte);
				}
				else if(requete.contains("compte")) {
					String ident = parametres.get("identifiant");
					String token = parametres.get("mdp");
					Compte compte = bdd.rechercheCompte(parametres.get("identifiant"));
					if(!bdd.connexion(ident, token)) {
						reponse = JsonFichier.jsonErreur("Erreur pas de compte avec l'identifiant : " + parametres.get("identifiant") + "ou ce mot de passe", "Not Fatal");
						return reponse;
					}
					reponse = JsonFichier.jsonCompte(compte);
				}
				else if(requete.contains("token")) {

				}
			}
			else if( mode.equals("POST")) {
				InputStream corp = exchange.getRequestBody();
				Scanner sc = new Scanner(corp);
				String corpString = sc.hasNext()?sc.next():"";

				if(requete.contains("compte")) {
					Compte compte = JsonFichier.lireCompteJson(corpString);
					Compte compte2 = bdd.rechercheCompte(parametres.get("identifiant"));
					if(compte2 == null) {
						bdd.ajouteCompte(compte);
						for(Map.Entry<Address, String> valeur : compte.getComptes().entrySet()) {
							bdd.ajouteAdresse(valeur.getKey(), valeur.getValue(), parametres.get("identifiant"));
						}
					}
					else if(!bdd.connexion(parametres.get("identifiant"), parametres.get("mdp"))) {
						reponse = JsonFichier.jsonErreur("Erreur pas de compte avec l'identifiant : " + parametres.get("identifiant") + "ou ce mot de passe", "Not Fatal");		
						return reponse;
					}
					if(!compte2.getMdp().equals(compte.getMdp())){
						bdd.changeMDP(parametres.get("identifiant"), compte.getMdp());
					}
					if(!compte2.getNom().equals(compte.getNom())) {
						//changement du nom
					}
					if(!compte2.getPrenom().equals(compte.getPrenom())) {
						//changement du prenom
					}
					for(Map.Entry<Address, String> valeur : compte.getComptes().entrySet()) {

						if(!compte2.getComptes().containsKey(valeur.getKey())) {
							bdd.ajouteAdresse(valeur.getKey(), valeur.getValue(), parametres.get("identifiant"));
						}
					}
				}
				else if(requete.contains("mail")) {
					if(bdd.connexion(parametres.get("identifiant"), parametres.get("mdp"))) {
						Compte compte = bdd.rechercheCompte(parametres.get("identifiant"));
						ArrayList<Mail> mails = JsonFichier.lireMailJson(corpString);
						for(Mail mail : mails) {
							try {
								Reseau.envoieMail(mail, compte);
								bdd.ajouteMail(mail);
							} catch (MessagingException e) {
								reponse = JsonFichier.jsonErreur("Nos services sont momentan�ment indisponible Erreur : " + e.getMessage(), "Fatal");
								return reponse;
							}

						}
					}
					else {
						reponse = JsonFichier.jsonErreur("Erreur pas de compte avec l'identifiant : " + parametres.get("identifiant") + "ou ce mot de passe", "Not Fatal");
					}

				}

			}
			else if( mode.equals("DELETE")) {
				InputStream corp = exchange.getRequestBody();
				Scanner sc = new Scanner(corp);
				String corpString = "";
				while(sc.hasNext())
					corpString += sc.next();
				if(requete.contains("mail")) {
					System.out.println("suppr Mails");
					if(bdd.connexion(parametres.get("identifiant"), parametres.get("mdp"))) {
						bdd.supprimeMail(JsonFichier.lireMailJson(corpString).get(0).getId());
					}
					else {
						reponse = JsonFichier.jsonErreur("Erreur pas de compte avec l'identifiant : " + parametres.get("identifiant") + "ou ce mot de passe", "Not Fatal");
						return reponse;
					}
				}
				else {
					if(bdd.connexion(parametres.get("identifiant"), parametres.get("mdp"))) {
						bdd.supprimeCompte(parametres.get("identifiant")); 				
					}
					else {
						reponse = JsonFichier.jsonErreur("Erreur pas de compte avec l'identifiant : " + parametres.get("identifiant") + "ou ce mot de passe", "Not Fatal");
						return reponse;
					}
				}

			}
		} catch (SQLException e) {
			reponse = JsonFichier.jsonErreur("Nos services sont momentan�ment indisponible Erreur : " + e.getMessage(), "Fatal");
		}
		return reponse;
	}



	@Override
	public void handle(HttpExchange exchange) throws IOException {


		String requestMethod = exchange.getRequestMethod();

		String query = exchange.getRequestURI().toString();


		String response = traitementRequete(exchange);
		System.out.println(response);

		if(response.contains("Erreur") && response.contains("Not Fatal"))
			exchange.sendResponseHeaders(400, response.length());
		else if (response.contains("Erreur"))
			exchange.sendResponseHeaders(503, response.length());
		else
			exchange.sendResponseHeaders(200, response.length());
		OutputStream os = exchange.getResponseBody();
		os.write(response.getBytes());
		os.close();

	}


	/*
	 * @param nb : String le nombre string � mettre en int
	 */
	private int stringToInt(String nb) {
		int ret = 0;
		for(int i = 0 ; i < nb.length() ; i++) {
			ret = (int) (ret + Math.pow(10, nb.length()-1 - i)* (nb.charAt(i)-48));
		}
		return ret;
	}
}