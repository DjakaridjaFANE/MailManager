package Objet;
import java.util.HashMap;

import javax.mail.*; 

public class Compte {

	private String identifiant;
	private HashMap<Address, String> comptes; 
    private String nom;
    private String prenom;
    private String mdp;

    /*
     * @param identifiant:String identifiant du compte
     * @param mdp:String mot de passe du compte
     * @param nom:String nom de la personne qui possede le compte
     * @param prenom:String prenom de la personne qui possede le compte
     * 
     */
    public Compte(String identifiant, String mdp, String nom, String prenom) {
        this.identifiant = identifiant;
        this.mdp = mdp;
        this.nom = nom;
        this.prenom = prenom;
        this.comptes = new HashMap<Address , String>();
    }
    
    /*
     * @param identifiant:String identifiant du compte
     * @param mdp:String mot de passe du compte
     * @param nom:String nom de la personne qui possede le compte
     * @param prenom:String prenom de la personne qui possede le compte
     * @param comptes:HashMap<Address, String> liste des adresses et mot de passe des clients de messageries
     */
    public Compte(String identifiant, String mdp, String nom, String prenom, HashMap<Address, String> comptes) {
        this.identifiant = identifiant;
        this.mdp = mdp;
        this.nom = nom;
        this.prenom = prenom;
        this.comptes = comptes;
    }
    
    /**
     * 
     * @return le mot de passe du compte
     */
    public String getMdp() {
        return this.mdp;
    }

    /**
     * 
     * @return le prenom associ� au compte
     */
    public String getPrenom() {
        return this.prenom;
    }

    /**
     * 
     * @return le nom associ� au compte
     */
    public String getNom() {
        return this.nom;
    }

    /**
     * 
     * @return l'identifiant du compte
     */
    public String getIdent() {
        return this.identifiant;
    }
    
    /**
     * 
     * @return la liste des adresses mail li�es au compte et de leur mot de passe
     */
    public HashMap<Address, String> getComptes() {
    	return comptes;
    }
    
 

    /**
     * 
     * @param nouveauPrenom: le nouveau pr�nom associ� au compte
     */
    public void setPrenom(String nouveauPrenom) {
        this.prenom = nouveauPrenom;
    }

    /**
     * 
     * @param nouveauNom: le nouveau nom associ� au compte
     */
    public void setNom(String nouveauNom) {
        this.nom = nouveauNom;
    }

    /**
     * 
     * @param nouveauMdp: le nouveau mot de passe du compte
     */
    public void setMdp(String nouveauMdp) {
        this.mdp = nouveauMdp;
    }

    /**
     * 
     * @param adresse: l'adresse � ajouter � la listes d'adresses associ�es au compte
     * @param motDePasse : mot de passe de connection � ajouter � la liste des mots de passes de connection
     * ne fait rien si adresse d�j� pr�sente
     */
    public void ajouteAddr(Address adresse , String motDePasse) {
        if (!comptes.containsKey(adresse) && !comptes.containsValue(motDePasse)) {
        	comptes.put(adresse, motDePasse);
        }
    }

    /**
     * 
     * @param adresse: l'adresse � supprimer de la liste des adresses associ�es au compte
     * @param motDePasse : mot de passe de connection � supprimer � la liste des mots de passes de connection
     * ne fait rien si adresse absente
     */
    public void supprimeAddr(Address adresse) {
    	if (comptes.containsKey(adresse)) {
        	comptes.remove(adresse);
        }
    }
    
	@Override
	public String toString() {
		
		return "Ident : " +identifiant+"\ncomptes<Address/mdp> : "+comptes+"\nnom : "+ nom+"\nprenom : "+prenom +"\nmdp : " +mdp;
	}
}
