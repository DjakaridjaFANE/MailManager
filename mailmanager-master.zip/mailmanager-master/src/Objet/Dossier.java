package Objet;
import java.util.ArrayList;

import javax.mail.*;

public class Dossier {

	private int id;
	private String nom;
	private Compte compte;/*
	private ArrayList<Mail> mails;
	private Temp suppression;*/
	
	/** Constructeur
	 * 
	 * @param nom
	 * @param id
	 * @param mails
	 * @param sup
	 */
	public Dossier(int id, String nom , Compte compte/*, ArrayList<Mail> mails, Temp sup*/) {
		this.nom = nom;
		this.id = id;
		this.setCompte(compte);
		/*this.mails = mails;
		this.suppression = sup;*/
	}
	
	/**
	 * 
	 * @return le nom du dossier
	 */
	public String getNom() {
		return this.nom;
	}
	
	/**
	 * 
	 * @param nom
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	/**
	 * 
	 * @return l'id du Dossier
	 */
	public int getId() {
		return this.id;
	}
	
	/**
	 * 
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	public Compte getCompte() {
		return compte;
	}

	public void setCompte(Compte compte) {
		this.compte = compte;
	}
	
	/**
	 * 
	 * @param m une liste de mail � ajouter
	 */
	/*public void ajouteMails(ArrayList<Mail> m) {
		this.mails.addAll(m);
	}
	
	/**
	 * 
	 * @param ad une liste de mail
	 */
	/*public void setMails(ArrayList<Mail> ad) {
		this.mails = ad;
	}
	
	/**
	 * 
	 * @return la liste d'adresse du dossier
	 */
	/*public ArrayList<Mail> getMails(){
		return this.mails;
	}
	
	/**
	 * 
	 * @param m une liste de mail � supprimer du dossier
	 */
	/*public void supprimeMails(ArrayList<Mail> m) {
		this.mails.removeAll(m);
	}
	
	/**
	 * 
	 * @param t le temps de suppression
	 */
	/*public void setSuppr(Temp t) {
		this.suppression = t;
	}
	
	/**
	 * 
	 * @return le temps de suppression
	 */
	/*public Temp getSuppr() {
		return this.suppression;
	}*/
	
}
