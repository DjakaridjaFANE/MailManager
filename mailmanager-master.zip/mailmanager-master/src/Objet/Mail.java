package Objet;
import java.util.ArrayList;
import java.util.Arrays;
import java.sql.Date;
import java.util.Iterator;

import javax.mail.*;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress; 


public class Mail {

	private int id;
	private Address expediteur;
	private ArrayList<Address> destinataires;
	private ArrayList<Address> cc;
	private ArrayList<Address> cci;
	private String objet;
	private ArrayList<String> piecesJointe;
	private Date date;
	private String contenu;

	/**Constructeur avec les parametres
	 * 
	 * @param id du mail
	 * @param expediteur l'expéditeur
	 * @param dest les destinataires
	 * @param cc les copies carbonnes
	 * @param cci les copies carbonnes invisibles
	 * @param obj l'objet
	 * @param pj les pièces jointes
	 * @param date la date
	 * @param contenu le contenu
	 */
	public Mail(int id, Address  expediteur, ArrayList<Address> dest, ArrayList<Address> cc, ArrayList<Address> cci, String obj, ArrayList<String> pj, Date date, String contenu){
		this.id = id;
		this.expediteur=expediteur;
		this.destinataires=dest;
		this.cc=cc;
		this.cci=cci;
		this.objet=obj;
		this.piecesJointe = pj;
		this.date=date;
		this.contenu=contenu;
	}


	/**Constructeur avec les parametres
	 * 
	 * @param expediteur l'expéditeur
	 * @param dest les destinataires
	 * @param cc les copies carbonnes
	 * @param cci les copies carbonnes invisibles
	 * @param obj l'objet
	 * @param pj les pièces jointes
	 * @param date la date
	 * @param contenu le contenu
	 */
	public Mail(Address  expediteur, ArrayList<Address> dest, ArrayList<Address> cc, ArrayList<Address> cci, String obj, ArrayList<String> pj, Date date, String contenu){
		this.id = -1;
		this.expediteur=expediteur;
		this.destinataires=dest;
		this.cc=cc;
		this.cci=cci;
		this.objet=obj;
		this.piecesJointe = pj;
		this.date=date;
		this.contenu=contenu;
	}



	/**Constructeur avec les parametres
	 * 
	 * @param expediteur l'expediteur
	 * @param dest les destinataires
	 * @param obj l'objet
	 * @param date la date
	 * @param contenu le contenu
	 */
	public Mail(int id, Address  expediteur, String obj, Date date, String contenu){
		this.id = id;
		this.expediteur=expediteur;
		this.destinataires= new ArrayList<Address>();
		this.cc=new ArrayList<Address>();
		this.cci=new ArrayList<Address>();
		this.objet=obj;
		this.piecesJointe = new ArrayList<String>();
		this.date=date;
		this.contenu=contenu;
	}


	/**Constructeur avec les parametres
	 * 
	 * @param m mail source � cloner
	 */
	public Mail(Mail m){
		this.id = m.id;
		try {
			this.expediteur = new InternetAddress(m.expediteur.toString());

			this.destinataires= new ArrayList<Address>();
			Iterator<Address> it = m.destinataires.iterator();
			while(it.hasNext()) {
				this.destinataires.add(new InternetAddress(it.next().toString()));
			}

			this.cc=new ArrayList<Address>();
			it = m.cc.iterator();
			while(it.hasNext()) {
				this.cc.add(new InternetAddress(it.next().toString()));
			}
			this.cci=new ArrayList<Address>();
			it = m.cci.iterator();
			while(it.hasNext()) {
				this.cci.add(new InternetAddress(it.next().toString()));
			}
		} catch (AddressException e) {
			e.printStackTrace();
		}

		this.objet=m.objet;
		this.piecesJointe = new ArrayList<String>();
		Iterator<String> it = m.piecesJointe.iterator();
		while(it.hasNext()) {
			this.piecesJointe.add(it.next());
		}
		this.date= new Date(m.date.getTime());
		this.contenu=m.contenu;
	}

	public Mail(){
		this.destinataires= new ArrayList<Address>();
		this.cc=new ArrayList<Address>();
		this.cci=new ArrayList<Address>();
		this.piecesJointe = new ArrayList<String>();
	}


	/**
	 * 
	 * @return L'adresse des destinataires
	 */
	/*public ArrayList<Address> getDestinataireList(){
		return this.destinataires;
	}*/

	public ArrayList<Address> getDestinataire(){
		return this.destinataires;
	}

	/**
	 * 
	 * @return Les copies carbonnes
	 */
	/*public ArrayList<Address> getCCList(){
		return this.cc;
	}*/

	public ArrayList<Address>  getCC(){
		return this.cc;
	}

	/**
	 * 
	 * @return Les copies carbonnes invisibles
	 */
	/*public ArrayList<Address> getCCIList(){
		return this.cci;
	}*/

	public ArrayList<Address>  getCCI(){
		return this.cci;
	}

	/**
	 * 
	 * @return L'adresse de l'expéditeur
	 */
	public Address getExpediteur(){
		return this.expediteur;
	}

	/**
	 * 
	 * @return L'objet
	 */
	public String getObjet(){
		return this.objet;
	}

	/**
	 * 
	 * @param PJ Les pièces jointes à ajouter
	 */
	public void ajoutePieceJointe(String[] pJ){
		for(String i : pJ){
			this.piecesJointe.add(i);
		}
	}

	public void ajoutePieceJointe(String pJ){
		this.piecesJointe.add(pJ);
	}

	/**
	 * 
	 * @param PJ Les pieces jointes a supprimer
	 */
	public void supprPieceJointe(String[] pJ){
		for(String i : pJ){
			this.piecesJointe.remove(i);
		}
	}

	/**
	 * 
	 * @return Le contenu du mail
	 */
	public String getContenu(){
		return this.contenu;
	}

	/**
	 * 
	 * @return La date
	 **/
	public Date getDate(){
		return this.date;
	}

	/**
	 * 
	 * @param dest Les destinataires a ajouter
	 */
	public void ajouteDestinataire(ArrayList<Address>  dest){
		for(Address i : dest){
			this.destinataires.add(i);
		}
	}

	public void ajouteDestinataire(Address dest){
		this.destinataires.add(dest);
	}

	/**
	 * 
	 * @param dest Les destinataires à supprimer
	 */
	public void supprDestinataire(ArrayList<Address>  dest){
		for(Address i : dest){
			this.destinataires.remove(i);
		}
	}

	/**
	 * 
	 * @param cc Les copies carbones a ajouter
	 */
	public void ajouteCC(ArrayList<Address>  cc){
		for(Address i : cc){
			this.cc.add(i);
		}
	}

	public void ajouteCC(Address cc){
		this.cc.add(cc);
	}

	/**
	 * 
	 * @param cc Les copies carbones a supprimer
	 */
	public void supprCC(ArrayList<Address>  cc){
		for(Address i : cc){
			this.cc.remove(i);
		}
	}

	/**
	 * 
	 * @param cci Les copies carbones invisbles a ajouter
	 */
	public void ajouteCCI(ArrayList<Address>  cci){
		for(Address i : cci){
			this.cci.add(i);
		}
	}

	public void ajouteCCI(Address cci){
		this.cci.add(cci);
	}

	/**
	 * 
	 * @param cci Les copies carbones invisbles a supprimer
	 */
	public void supprCCI(ArrayList<Address>  cci){
		for(Address i : cci){
			this.cci.remove(i);
		}
	}

	/**
	 * 
	 * @param exp L'expediteur
	 */
	public void setExpediteur(Address exp){
		this.expediteur=exp;
	}

	/**
	 * 
	 * @param obj l'objet
	 */
	public void setObjet(String obj){
		this.objet=obj;
	}

	/**
	 * 
	 * @param contenu le contenu
	 */
	public void setContenu(String contenu){
		this.contenu=contenu;
	}

	/**
	 * 
	 * @param date la date
	 */
	public void setDate(Date date){
		this.date=date;
	}

	/**
	 * 
	 * @param PJ les pieces jointes
	 */
	public void setPiecesJointe(ArrayList<String> pj){
		this.piecesJointe= pj;
	}

	/**
	 * 
	 * @return les pieces jointes
	 */
	/*public ArrayList<String> getPiecesJointesList() {
		return this.piecesJointe;
	}*/

	public ArrayList<String> getPiecesJointes() {
		return this.piecesJointe;
	}
	/*
	 * clear de l'array destinataires
	 * */
	public void clearDest() {
		this.destinataires.clear();
	}

	/*
	 * clear de l'array CC
	 * */
	public void clearCC() {
		this.cc.clear();
	}

	/*
	 * clear de l'array CCI
	 * */
	public void clearCCI() {
		this.cci.clear();
	}

	/*
	 * clear de l'array piecesJointe
	 * */
	public void clearPiecesJointe() {
		this.piecesJointe.clear();
	}

	@Override 
	public String toString() {
		String str = 
				"Expediteur : " + this.expediteur.toString() 
				+ "\nDestinataires : " + this.destinataires.toString()
				+ "\nCC : " + this.cc.toString()
				+ "\nCCI : " + this.cci.toString()
				+ "\nObjet : " + this.objet
				+ "\nPieces Jointes : " + this.piecesJointe.toString()
				+ "\nDate : " + this.date.toString()
				+ "\nContenu : " + this.contenu.toString()+"\n";
		return str;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
