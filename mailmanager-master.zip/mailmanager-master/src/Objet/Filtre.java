package Objet;
import ConditionPackage.Condition;

public class Filtre {
	private String nom;
	private int id;
	private Condition cond;
	
	/** Constructeur
	 * 
	 * @param nom
	 * @param id
	 * @param cond
	 */
	public Filtre(String nom, int id, Condition cond) {
		this.nom = nom;
		this.id = id;
		this.cond = cond;
	}
	
	/**
	 * 
	 * @return le nom du filtre
	 */
	public String getNom() {
		return this.nom;
	}
	
	/**
	 * 
	 * @return l'id du filtre
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * 
	 * @return la condition du filtre
	 */
	public Condition getCondition() {
		return cond;
	}
	
	/**
	 * 
	 * @param nom
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	/**
	 * 
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 
	 * @param cond
	 */
	public void setCond(Condition cond) {
		this.cond = cond;
	}
	
}
