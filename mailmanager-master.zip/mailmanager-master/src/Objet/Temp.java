package Objet;
import java.util.ArrayList;

public class Temp {
	private int Annee;
	private int Mois;
	private int Semaine;
	private int Jour;
	private int Heure;
	private int Minute;
	private int Seconde;
	
	/**Constructeur
	 * 
	 * @param Annee
	 * @param Mois
	 * @param Semaine
	 * @param Jour
	 * @param Heure
	 * @param Minute
	 * @param Seconde
	 */
	public Temp(int Annee, int Mois, int Semaine, int Jour, int Heure, int Minute, int Seconde) {
		this.Annee=Annee;
		this.Mois=Mois;
		this.Semaine=Semaine;
		this.Jour=Jour;
		this.Heure=Heure;
		this.Minute=Minute;
		this.Seconde=Seconde;
	}
	
	/**
	 * 
	 * @param Annee
	 * @param Mois
	 * @param Semaine
	 * @param Jour
	 * @param Heure
	 * @param Minute
	 * @param Seconde
	 */
	public void setTemp(int Annee, int Mois, int Semaine, int Jour, int Heure, int Minute, int Seconde) {
		this.Annee=Annee;
		this.Mois=Mois;
		this.Semaine=Semaine;
		this.Jour=Jour;
		this.Heure=Heure;
		this.Minute=Minute;
		this.Seconde=Seconde;
	}
	
	/**
	 * 
	 * @return le temps
	 */
	public ArrayList<Integer> getTemp() {
		ArrayList<Integer>temp = new ArrayList<Integer>();
		temp.add(this.Annee);
		temp.add(this.Mois);
		temp.add(this.Semaine);
		temp.add(this.Jour);
		temp.add(this.Heure);
		temp.add(this.Minute);
		temp.add(this.Seconde);
		return temp;
	}
	
}