import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.mail.*;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import Objet.Compte;
import Objet.Dossier;
import Objet.Mail;

public class BDD {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;

	public BDD() {
		String url = "jdbc:mysql://localhost:3306/mail manager";
		String host = "root";
		String mdp = "123456";//"eft3gv4AAJTID91*";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			this.con = DriverManager.getConnection(url,host,mdp);   
			System.out.println("Connected"); 
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @param mail a ajoute a la bdd
	 * 
	 * @return true si le mail a ete ajoute
	 * */
	public boolean ajouteMail(Mail mail) throws SQLException {
		this.stmt = this.con.prepareStatement(
				"INSERT INTO mail (objet, date, contenu, expediteur) VALUES (?,?,?,?)",Statement.RETURN_GENERATED_KEYS
				);
		this.stmt.setString(1, mail.getObjet());
		this.stmt.setDate(2, mail.getDate());
		this.stmt.setString(3, mail.getContenu());
		this.stmt.setString(4, mail.getExpediteur().toString());

		if(this.stmt.executeUpdate()==1) {
			this.rs = stmt.getGeneratedKeys();
			int idMail=-1;
			if (rs.next()) {
				idMail = rs.getInt(1);
			}
			Address[] dest = mail.getDestinataire().toArray(new Address[0]);
			Address[] cc = mail.getCC().toArray(new Address[0]);
			Address[] cci = mail.getCCI().toArray(new Address[0]);
			String[] pj = mail.getPiecesJointes().toArray(new String[0]);
			int length = Math.max(Math.max(dest.length, cc.length), Math.max(cci.length, pj.length));
			for(int i = 0; i < length; i++) {
				//while(dest.hasNext() || cc.hasNext() || cci.hasNext() || pj.hasNext()) {
				this.stmt = this.con.prepareStatement(
						"INSERT INTO `mailen-tete` (idMail , destinataire, cc, cci, piecesJointes) VALUES (?,?,?,?,?)"
						);
				this.stmt.setInt(1, idMail);

				if(i < dest.length)
					this.stmt.setString(2, dest[i].toString());
				else
					this.stmt.setNull(2, Types.BLOB);

				if(i < cc.length)
					this.stmt.setString(3, cc[i].toString());
				else
					this.stmt.setNull(3, Types.BLOB);

				if(i < cci.length)
					this.stmt.setString(4, cci[i].toString());
				else
					this.stmt.setNull(4, Types.BLOB);

				if(i < pj.length)
					this.stmt.setString(5, pj[i]);
				else
					this.stmt.setNull(5, Types.BLOB);

				if(this.stmt.executeUpdate()!=1)
					return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * @param id du mail a supprime
	 * 
	 * @return true le mail est supprime faux sinon
	 * */
	public boolean supprimeMail(int id) throws SQLException {

		this.stmt = this.con.prepareStatement(
				"DELETE FROM `mailen-tete` WHERE idMail = ?"
				);
		this.stmt.setInt(1, id);
		this.stmt.executeUpdate();

		this.stmt = this.con.prepareStatement(
				"DELETE FROM mail WHERE id = ?"
				);
		this.stmt.setInt(1, id);
		this.stmt.executeUpdate();
		return true;
	}

	/**
	 * 
	 * @param ad l'adresse a ajouter
	 * @param mdp le mdp correspondant
	 * @param ident l'identifiant du compte
	 * @return
	 * @throws SQLException
	 */
	public boolean ajouteAdresse(Address ad, String mdp, String ident) throws SQLException {
		String adresse = ad.toString();
		this.stmt = this.con.prepareStatement(
				"SELECT ident FROM compte WHERE ident = ?"
				);
		this.stmt.setString(1, ident);
		this.rs = this.stmt.executeQuery();

		if(!this.rs.next()) return false; //compte non-pr�sent dans la BDD

		this.stmt = this.con.prepareStatement(
				"INSERT INTO compteaddress (address, mdp, idCompte) VALUES (?,?,?)"
				);
		this.stmt.setString(1, adresse);
		this.stmt.setString(2, mdp);
		this.stmt.setString(3, ident);

		return this.stmt.executeUpdate()==1;
	}

	/**
	 * @param adresse a supprime
	 * @param ident du compte associe a l'adresse a supprime
	 * 
	 * @return true si l'adresse est supprim� faut sinon
	 * */
	public boolean supprimeAdresse(Address ad, String ident) throws SQLException {
		this.stmt = this.con.prepareStatement(
				"SELECT ident FROM compte WHERE ident = ?"
				);
		this.stmt.setString(1, ident);
		this.rs = this.stmt.executeQuery();

		if(!this.rs.next()) return false; //compte non-pr�sent dans la BDD


		this.stmt = this.con.prepareStatement(
				"DELETE FROM compteaddress WHERE idCompte = ? And address = ?"
				);
		this.stmt.setString(1, ident);
		this.stmt.setString(2, ad.toString());
		return this.stmt.executeUpdate()==1;
	}

	/**
	 * change le mot de passe du compte d'id "id" par "mdp"
	 * 
	 * @param mdp : nouveau mot de passe dans la bd
	 * 
	 * @return true si mdp est chang�
	 * 		   false sinon
	 * 
	 */
	public boolean changeMDP(String ident, String mdp) throws SQLException {
		//TODO Hash mdp

		//update de la base de donn�es
		this.stmt = this.con.prepareStatement(
				"UPDATE compte SET mdp = ? WHERE ident = ?"
				);
		stmt.setString(1, mdp);
		stmt.setString(2, ident);

		return this.stmt.executeUpdate()!=0;
	}

	/**
	 * Recherche du mail d'id "id"
	 * 
	 * @param id : id du mail a rechercher 
	 * 
	 * @return le Mail si trouv� null sinon
	 */
	public Mail rechercheMail(int id) throws SQLException {

		//Verification de l'existance du mail
		this.stmt = this.con.prepareStatement(
				"SELECT COUNT(*) FROM mail WHERE id = ?"
				);
		stmt.setInt(1, id);
		this.rs = this.stmt.executeQuery();
		while(rs.next()) {
			//s'il n'existe pas on renvoie null
			if (rs.getInt(1) != 1)
				return null;
		}

		//recherche du Mail part 1
		this.stmt = this.con.prepareStatement(
				"SELECT objet, date, contenu, expediteur FROM mail WHERE id = ?"
				);
		stmt.setInt(1, id);
		this.rs = this.stmt.executeQuery();

		Mail result= null;
		while (rs.next()) {
			try {
				result = new Mail(id,new InternetAddress(rs.getString(4)),rs.getString(1),rs.getDate(2),rs.getString(3));
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//recherche du Mail part 2
		this.stmt = this.con.prepareStatement(
				"SELECT destinataire, cc, cci, piecesJointes FROM `mailen-tete` WHERE idMail = ?;"
				);
		stmt.setInt(1, id);
		this.rs = this.stmt.executeQuery();

		//Remplissage de result
		String s;
		try {
			while(rs.next()) {
				s = rs.getString(1);
				if(s != null)
					result.ajouteDestinataire(new InternetAddress(s));

				s = rs.getString(2);
				if(s != null)
					result.ajouteCC(new InternetAddress(s));

				s = rs.getString(3);
				if(s != null)
					result.ajouteCCI(new InternetAddress(s));

				s = rs.getString(4);
				if(s != null)
					result.ajoutePieceJointe(new String(s));
			}
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	
	/**
	 * Recherche du mail d'id "id"
	 * 
	 * @param expediteur : expediteur des mails a rechercher 
	 * @param destinataire : destinataire des mails a rechercher 
	 * @param cc : cc des mails a rechercher 
	 * @param cci : cci des mails a rechercher
	 * @param idDossier : id du dossier dans lequel chercher les mails si aucun
	 * 
	 * @return une Arraylist de Mail si trouv� null sinon
	 */
	public ArrayList<Mail> rechercheMail(Address exp, ArrayList<Address> dest, ArrayList<Address> cc, ArrayList<Address> cci, int idDossier) throws SQLException {
		if(exp == null && dest == null && cc == null && cci == null)
			return null;

		ArrayList<Mail> result = new ArrayList<Mail>();
		String s = "";
		ArrayList<String> list = new ArrayList<String>();
		int cpt = 0;
		Iterator<Address> it;
		//Verification de l'existance du mail
		if(exp != null) {
			s += "AND expediteur = ? ";
			list.add(exp.toString());
		}

		if(dest != null) {
			it = dest.iterator();
			if(it.hasNext()) {
				s += "AND destinataire IN ( ?";
				list.add(it.next().toString());

				while(it.hasNext()) {
					s += ", ?";
					list.add(it.next().toString());
				}
				s += ") ";
			}
		}

		if(cc != null) {
			it = cc.iterator();
			if(it.hasNext()) {
				s += "AND cc IN ( ?";
				list.add(it.next().toString());

				while(it.hasNext()) {
					s += ", ?";
					list.add(it.next().toString());
				}
				s += ") ";
			}
		}

		if(cci != null) {
			it = cci.iterator();
			if(it.hasNext()) {
				s += "AND cci IN ( ?";
				list.add(it.next().toString());

				while(it.hasNext()) {
					s += ", ?";
					list.add(it.next().toString());
				}
				s += ") ";
			}
		}
		System.out.println("SELECT COUNT(*) FROM mail m, `mailen-tete` mT WHERE m.id = mT.idMail "+s);
		if(idDossier <= 0)
			this.stmt = this.con.prepareStatement("SELECT COUNT(*) FROM mail m, `mailen-tete` mT WHERE m.id = mT.idMail "+s);
		else {
			this.stmt = this.con.prepareStatement("SELECT COUNT(*) FROM mail m, `mailen-tete` mT, `dossierMail` dM WHERE dM.idMail = m.idMail AND m.id = mT.idMail AND dM.idDossier = ? "+s);
			this.stmt.setInt(++cpt, idDossier);
		}
		Iterator<String> it2 = list.iterator();
		while(it2.hasNext()) {
			this.stmt.setString(++cpt, it2.next());
		}
		this.rs = this.stmt.executeQuery();

		while(rs.next()) {
			//s'il en existe aucun on renvoie null
			if (rs.getInt(1) == 0)
				return null;
		}

		//Recherche des Mail
		cpt = 0;
		if(idDossier <= 0)
			this.stmt = this.con.prepareStatement("SELECT m.id AS id,m.expediteur AS exp, mt.destinataire AS dest, mt.cc AS cc, mt.cci AS cci, m.objet AS objet, mt.piecesJointes AS pj, m.date AS date, m.contenu AS contenu FROM mail m, `mailen-tete` mT WHERE m.id = mT.idMail "+s);
		else {
			this.stmt = this.con.prepareStatement("SELECT m.id AS id,m.expediteur AS exp, mt.destinataire AS dest, mt.cc AS cc, mt.cci AS cci, m.objet AS objet, mt.piecesJointes AS pj, m.date AS date, m.contenu AS contenu FROM mail m, `mailen-tete` mT, `dossierMail` dM WHERE dM.idMail = m.idMail AND m.id = mT.idMail AND dM.idDossier = ? "+s);
			this.stmt.setInt(++cpt, idDossier);
		}
		
		it2 = list.iterator();
		while(it2.hasNext()) {
			this.stmt.setString(++cpt, it2.next());
		}
		this.rs = this.stmt.executeQuery();

		int lastId = 0;
		Mail lastMail = new Mail();

		//Remplissage du result avec le resultat de la requete

		while(rs.next()) {
			//un nouveau mail a traiter
			if(lastId != rs.getInt("id")) {
				lastId = rs.getInt("id");
				//mail rempli a mettre dans la liste
				if(lastMail.getObjet() != null) {
					//ajout du clone dans la liste
					result.add(new Mail(lastMail));
					lastMail.clearCC();
					lastMail.clearCCI();
					lastMail.clearDest();
					lastMail.clearPiecesJointe();
				}
				//remplissage de l'objet mail avec les param�tre du nouveau mail rencontrer
				try {
					lastMail.setExpediteur(new InternetAddress(rs.getString("exp")));
				} catch (AddressException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				lastMail.setId(lastId);
				lastMail.setObjet(rs.getString("objet"));
				lastMail.setDate(rs.getDate("date"));
				lastMail.setContenu(rs.getString("contenu"));
			}
			//remplissage des listes du mail
			try {
				s = rs.getString("dest");
				if(s != null)
					lastMail.ajouteDestinataire(new InternetAddress(s));


				s = rs.getString("cc");
				if(s != null)
					lastMail.ajouteCC(new InternetAddress(s));

				s = rs.getString("cci");
				if(s != null)
					lastMail.ajouteCCI(new InternetAddress(s));

				s = rs.getString("pj");
				if(s != null)
					lastMail.ajoutePieceJointe(new String(s));
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//ajout du dernier mail non ajouter
		result.add(lastMail);
		return result;
	}
	
	/**
	
	
	/**
	 * @param ident de connexion
	 * @param mdp de connextion
	 * 
	 * @return true si l'ident et le mdp sont correct faux sinon
	 * */
	public boolean connexion(String ident, String mdp) throws SQLException {
		//Verification de l'existance du compte
		this.stmt = this.con.prepareStatement(
				"SELECT COUNT(*) FROM compte WHERE ident = ?"
				);
		stmt.setString(1, ident);
		this.rs = this.stmt.executeQuery();
		while(rs.next()) {
			//s'il n'existe pas on renvoie faux
			if (rs.getInt(1) != 1)
				return false;
		}

		//recherche du Compte part 1
		this.stmt = this.con.prepareStatement(
				"SELECT mdp FROM compte WHERE ident = ?"
				);
		stmt.setString(1, ident);
		this.rs = this.stmt.executeQuery();

		while (rs.next()) {
			return mdp.equals(rs.getString(1));
		}
		return false;
	}

	/**
	 * @param Compte a ajoute a la bdd
	 * le compte ne contient pas d'adresse
	 * 
	 * @result vrai si le compte peut etre ajoute a la bdd faux sinon
	 */
	public boolean ajouteCompte(Compte compte) throws SQLException{
		this.stmt = this.con.prepareStatement(
				"SELECT ident FROM compte WHERE ident = ?"
				);
		this.stmt.setString(1, compte.getIdent());
		this.rs = this.stmt.executeQuery();

		if(this.rs.next()) return false; //compte pr�sent dans la BDD

		this.stmt = this.con.prepareStatement(
				"INSERT INTO compte (ident, nom, prenom, mdp) VALUES (?,?,?,?)"
				);
		this.stmt.setString(1, compte.getIdent());
		this.stmt.setString(2, compte.getNom());
		this.stmt.setString(3, compte.getPrenom());
		this.stmt.setString(4, compte.getMdp());

		return(this.stmt.executeUpdate()==1);
	}

	/**
	 * @param ident du Compte a supprime a la bdd
	 * 
	 * @result vrai si supprime faux sinon
	 */
	public boolean supprimeCompte(String ident) throws SQLException{
		this.stmt = this.con.prepareStatement(
				"SELECT ident FROM compte WHERE ident = ?"
				);
		this.stmt.setString(1, ident);
		this.rs = this.stmt.executeQuery();

		if(!this.rs.next()) return false; //compte non-pr�sent dans la BDD


		this.stmt = this.con.prepareStatement(
				"DELETE FROM compteaddress WHERE idCompte = ?"
				);
		this.stmt.setString(1, ident);
		this.stmt.executeUpdate();

		this.stmt = this.con.prepareStatement(
				"DELETE FROM compte WHERE ident = ?"
				);
		this.stmt.setString(1, ident);
		this.stmt.executeUpdate();
		return true;
	}

	/**
	 * @param ident du Compte a recherche dans la bdd
	 * 
	 * @result le compte associe s'il existe null sinon
	 */
	public Compte rechercheCompte(String ident) throws SQLException{
		//Verification de l'existance du mail
		this.stmt = this.con.prepareStatement(
				"SELECT COUNT(*) FROM compte WHERE ident = ?"
				);
		stmt.setString(1, ident);
		this.rs = this.stmt.executeQuery();
		while(rs.next()) {
			//s'il n'existe pas on renvoie null
			if (rs.getInt(1) != 1)
				return null;
		}

		//recherche du Compte part 1
		this.stmt = this.con.prepareStatement(
				"SELECT nom, prenom, mdp FROM compte WHERE ident = ?"
				);
		stmt.setString(1, ident);
		this.rs = this.stmt.executeQuery();

		Compte result= null;
		while (rs.next()) {
			result = new Compte(ident,rs.getString(3),rs.getString(1),rs.getString(2));
		}

		//recherche du Mail part 2
		this.stmt = this.con.prepareStatement(
				"SELECT address, mdp FROM compteaddress WHERE idCompte = ?;"
				);
		stmt.setString(1, ident);
		this.rs = this.stmt.executeQuery();

		//Remplissage de result
		while(rs.next()) {
			try {
				result.ajouteAddr(new InternetAddress(rs.getString(1)), rs.getString(2));
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}

	/**
	 * @param ident du Compte a ajoute a la bdd
	 * 
	 * @result true si faite false
	 */
	public boolean changeNom(String ident, String nom, String prenom) throws SQLException{
		//update de la base de donn�es
		this.stmt = this.con.prepareStatement(
				"UPDATE compte SET nom = ?, prenom = ? WHERE ident = ?"
				);
		stmt.setString(1, nom);
		stmt.setString(2, prenom);
		stmt.setString(3, ident);
		return this.stmt.executeUpdate()!=0;
	}

	/**
	 * @param ident du compte du dossier
	 * @param nom du dossier a ajouter
	 * 
	 * @result true si ajoute false sinon
	 */
	public boolean ajoutDossier(String ident, String nom) throws SQLException{
		this.stmt = this.con.prepareStatement(
				"SELECT ident FROM dossier WHERE idCompte = ? AND nom = ?"
				);
		this.stmt.setString(1, ident);
		this.stmt.setString(2, nom);
		this.rs = this.stmt.executeQuery();

		if(this.rs.next()) return false; //compte pr�sent dans la BDD

		this.stmt = this.con.prepareStatement(
				"INSERT INTO dossier (nom, idCompte) VALUES (?,?)"
				);
		this.stmt.setString(1, nom);
		this.stmt.setString(2, ident);

		return(this.stmt.executeUpdate()==1);
	}

	/**
	 * @param ident du compte du dossier
	 * @param nom du dossier a supprimer
	 * 
	 * @result true si supprime false sinon
	 */
	public boolean supprimeDossier(String ident, String nom) throws SQLException{
		this.stmt = this.con.prepareStatement(
				"SELECT id FROM Dossier WHERE idCompte = ? AND nom = ?"
				);
		this.stmt.setString(1, ident);
		this.stmt.setString(2, nom);
		this.rs = this.stmt.executeQuery();

		int idDossier;
		if(!this.rs.next())
			return false; //Dossier non-pr�sent dans la BDD

		idDossier = rs.getInt(1);

		this.stmt = this.con.prepareStatement(
				"DELETE FROM dossierMail WHERE idDossier = ?"
				);
		this.stmt.setInt(1, idDossier);
		this.stmt.executeUpdate();

		this.stmt = this.con.prepareStatement(
				"DELETE FROM dossier WHERE id = ?"
				);
		this.stmt.setInt(1, idDossier);
		this.stmt.executeUpdate();
		return true;
	}

	/**
	 * @parma compte associ� au dossier
	 * @param nom du dossier dans la bdd
	 * 
	 * @result le dossier avec le nom associe au compte s'il existe null sinon
	 */
	public Dossier rechercheDossier(Compte compte, String nom) throws SQLException{
		//Verification de l'existance du mail
		this.stmt = this.con.prepareStatement(
				"SELECT COUNT(*) FROM dossier WHERE idCompte = ? AND nom = ?"
				);
		this.stmt.setString(1, compte.getIdent());
		this.stmt.setString(1, nom);
		this.rs = this.stmt.executeQuery();
		while(rs.next()) {
			//s'il n'existe pas on renvoie null
			if (rs.getInt(1) < 1)
				return null;
		}

		//recherche du Compte part 1
		this.stmt = this.con.prepareStatement(
				"SELECT id FROM dossier WHERE ident = ? AND nom = ?"
				);
		this.stmt.setString(1, compte.getIdent());
		this.stmt.setString(1, nom);
		this.rs = this.stmt.executeQuery();

		Dossier result= null;
		if(rs.next()) {
			result = new Dossier(rs.getInt(1), nom, compte);
		}
		return result;
	}
	
	/**
	 * @parma compte associ� au dossier
	 * 
	 * @result le dossier avec le nom associe au compte s'il existe null sinon
	 */
	public ArrayList<Dossier> rechercheDossier(Compte compte) throws SQLException{
		//Verification de l'existance du mail
		this.stmt = this.con.prepareStatement(
				"SELECT COUNT(*) FROM dossier WHERE idCompte = ?"
				);
		this.stmt.setString(1, compte.getIdent());
		this.rs = this.stmt.executeQuery();
		while(rs.next()) {
			//s'il n'existe pas on renvoie null
			if (rs.getInt(1) < 1)
				return null;
		}

		//recherche du Compte part 1
		this.stmt = this.con.prepareStatement(
				"SELECT id, nom FROM dossier WHERE ident = ? AND nom = ?"
				);
		this.stmt.setString(1, compte.getIdent());
		this.rs = this.stmt.executeQuery();

		ArrayList<Dossier> result= new ArrayList<Dossier>();
		while(rs.next()) {
			result.add(new Dossier(rs.getInt(1),rs.getString(2), compte));
		}
		return result;
	}

	public boolean ajouteMailDossier(int idMail, Dossier dos) throws SQLException {
		this.stmt = this.con.prepareStatement(
				"SELECT COUNT(*) FROM dossierMail WHERE idMail = ? AND idDossier = ?"
				);
		this.stmt.setInt(1, idMail);
		this.stmt.setInt(2, dos.getId());
		this.rs = this.stmt.executeQuery();

		if(this.rs.next())
			if(this.rs.getInt(1)==0)
				return false; //compte pr�sent dans la BDD

		this.stmt = this.con.prepareStatement(
				"INSERT INTO dossier (idMail, idCompte) VALUES (?,?)"
				);
		this.stmt.setInt(1, idMail);
		this.stmt.setInt(2, dos.getId());

		return(this.stmt.executeUpdate()==1);
	}
	
	public boolean supprimeMailDossier(int idMail, Dossier dos) throws SQLException{
		this.stmt = this.con.prepareStatement(
				"DELETE FROM dossierMail WHERE idMail = ?, idDossier = ?"
				);
		this.stmt.setInt(1, idMail);
		this.stmt.setInt(2, dos.getId());
		return this.stmt.executeUpdate()==0;
	}
	
	/**
	 * Recherche du mail d'id "id"
	 * 
	 * @param Compte qui contient les adresses � afficher
	 * 
	 * @return une Arraylist de Mail si trouv� null sinon
	 */
	public ArrayList<Mail> allMail(Compte compte) throws SQLException {
		ArrayList<String> addr = new ArrayList<String>();
		for (Entry<Address, String> mapentry : compte.getComptes().entrySet()) {
			addr.add(mapentry.getKey().toString());
		}
		String s = "(";
		Iterator<String> it = addr.iterator();
		if(it.hasNext())
			s += "'"+it.next()+"'";
		while(it.hasNext()) {
			s += ","+"'"+it.next()+"'";
		}
		s += ")";

		this.stmt = this.con.prepareStatement("SELECT COUNT(*) FROM mail m, `mailen-tete` mT WHERE m.id = mT.idMail AND (expediteur IN" + s + "OR destinataire IN" + s + "OR cc IN" + s + "OR cci IN" + s + ")");
		//System.out.println("SELECT COUNT(*) FROM mail m, `mailen-tete` mT WHERE m.id = mT.idMail AND (expediteur IN" + s + "OR destinataire IN" + s + "OR cc IN" + s + "OR cci IN" + s + ")");
		this.rs = this.stmt.executeQuery();

		if(this.rs.next())
			if(this.rs.getInt(1)==0)
				return null;
		
		this.stmt = this.con.prepareStatement("SELECT m.id AS id,m.expediteur AS exp, mt.destinataire AS dest, mt.cc AS cc, mt.cci AS cci, m.objet AS objet, mt.piecesJointes AS pj, m.date AS date, m.contenu AS contenu FROM mail m, `mailen-tete` mT WHERE m.id = mT.idMail AND (expediteur IN" + s + "OR destinataire IN" + s + "OR cc IN" + s + "OR cci IN" + s + ") ORDER BY id");
		this.rs = this.stmt.executeQuery();
		ArrayList<Mail> result = new ArrayList<Mail>();
		int lastId = 0;
		Mail lastMail = new Mail();
		//Remplissage du result avec le resultat de la requete
		while(rs.next()) {
			//un nouveau mail a traiter
			if(lastId != rs.getInt("id")) {
				lastId = rs.getInt("id");
				//mail rempli a mettre dans la liste
				if(lastMail.getObjet() != null) {
					//ajout du clone dans la liste
					result.add(new Mail(lastMail));
					lastMail.clearCC();
					lastMail.clearCCI();
					lastMail.clearDest();
					lastMail.clearPiecesJointe();
				}
				//remplissage de l'objet mail avec les param�tre du nouveau mail rencontrer
				try {
					lastMail.setExpediteur(new InternetAddress(rs.getString("exp")));
				} catch (AddressException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				lastMail.setId(lastId);
				lastMail.setObjet(rs.getString("objet"));
				lastMail.setDate(rs.getDate("date"));
				lastMail.setContenu(rs.getString("contenu"));
			}
			//remplissage des listes du mail
			try {
				s = rs.getString("dest");
				if(s != null)
					lastMail.ajouteDestinataire(new InternetAddress(s));


				s = rs.getString("cc");
				if(s != null)
					lastMail.ajouteCC(new InternetAddress(s));

				s = rs.getString("cci");
				if(s != null)
					lastMail.ajouteCCI(new InternetAddress(s));

				s = rs.getString("pj");
				if(s != null)
					lastMail.ajoutePieceJointe(new String(s));
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//ajout du dernier mail non ajouter
		result.add(lastMail);
		return result;
	}
}
