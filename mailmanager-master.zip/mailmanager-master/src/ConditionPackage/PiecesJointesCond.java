package ConditionPackage;
import Objet.Dossier;

public class PiecesJointesCond extends Condition {
	
	private String PieceJointes;
	
	/** Constructeur
	 * 
	 * @param d le dossier de la condition
	 * @param pj la pi�ce jointe
	 */
	public PiecesJointesCond(Dossier d, String pj) {
		super(d);
		this.PieceJointes=pj;
	}
}
