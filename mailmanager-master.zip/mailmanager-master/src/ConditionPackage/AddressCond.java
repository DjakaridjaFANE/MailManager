package ConditionPackage;
import javax.mail.*;

import Objet.Dossier;



public class AddressCond extends Condition {

	private Address address;
	
	/** Constructeur
	 * 
	 * @param d le dossier de la condition
	 * @param ad l'adresse en condition
	 */
	public AddressCond(Dossier d, Address ad) {
		super(d);
		this.address = ad;
	}
	
	/**
	 * 
	 * @return l'adresse en condition
	 */
	public Address getAddress() {
		return address;
	}
	
	/**
	 * 
	 * @param ad l'adresse a mettre en condition
	 */
	public void setAddress(Address ad) {
		this.address=ad;
	}
	
}
