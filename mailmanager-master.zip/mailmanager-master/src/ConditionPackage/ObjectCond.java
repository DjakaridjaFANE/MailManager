package ConditionPackage;
import Objet.Dossier;

public class ObjectCond extends Condition {

	private String objet;
	
	/**
	 * 
	 * @param d le dossier de la condition
	 * @param obj l'objet en condition
	 */
	public ObjectCond(Dossier d, String obj) {
		super(d);
		this.objet = obj;
	}
	
	/**
	 * 
	 * @return l'objet en condition
	 */
	public String getObjet() {
		return objet;
	}
	
	/**
	 * 
	 * @param obj l'objet en condition
	 */
	public void setObjet(String obj) {
		this.objet = obj;
	}
	
}
