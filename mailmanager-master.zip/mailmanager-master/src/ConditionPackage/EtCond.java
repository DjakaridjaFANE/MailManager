package ConditionPackage;
import Objet.Dossier;

public class EtCond extends Condition {

	private Condition cond1;
	private Condition cond2;
	
	/** Constructeur
	 * 
	 * @param d le dossier de la condition
	 * @param c1 la premi�re condition
	 * @param c2 la deuxi�me condtion
	 */
	public EtCond(Dossier d, Condition c1, Condition c2) {
		super(d);
		this.cond1 = c1;
		this.cond2 = c2;
	}
	
	/**
	 * 
	 * @return la premi�re condition
	 */
	public Condition getCond1() {
		return this.cond1;
	}
	
	/**
	 * 
	 * @return la deuxi�me condtion
	 */
	public Condition getCond2() {
		return this.cond2;
	}
	
	/**
	 * 
	 * @param c la premi�re condition
	 */
	public void setCond1(Condition c) {
		this.cond1 = c;
	}
	
	/**
	 * 
	 * @param c la deuxi�me condtion
	 */
	public void setCond2(Condition c) {
		this.cond2 = c;
	}
	
}
