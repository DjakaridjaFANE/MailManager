package ConditionPackage;
import java.util.ArrayList;

import Objet.Dossier;

public class MotCond extends Condition {

	private ArrayList<String> mots;
	
	/**
	 * 
	 * @param d le dossier de la condition
	 * @param m une liste de String en condition
	 */
	public MotCond(Dossier d, ArrayList<String> m) {
		super(d);
		this.mots = m;
	}
	
	/**
	 * 
	 * @param mot un String � ajouter � la condition
	 */
	public void ajouterMot(String mot) {
		this.mots.add(mot);
	}
	
	/**
	 * 
	 * @param mot un string � retirer de la condtion
	 */
	public void supprimerMot(String mot) {
		this.mots.remove(mot);
	}
	
	/**
	 * 
	 * @return la liste en condtion
	 */
	public ArrayList<String> getMots(){
		return mots;
	}
	
	/**
	 * 
	 * @param mots une liste de String comme condition
	 */
	public void setMots(ArrayList<String> mots) {
		this.mots = mots;
	}

}
