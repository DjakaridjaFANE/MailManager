package ConditionPackage;
import Objet.Dossier;

public abstract class Condition {
	
	private Dossier dossier;
	
	/**
	 * 
	 * @param d le dossier de la condition
	 */
	public Condition(Dossier d) {
		this.dossier = d;
	}
	
	/**
	 * 
	 * @return le dossier de la condition
	 */
	public Dossier getDossier() {
		return this.dossier;
	}
	
	/**
	 * 
	 * @param dossier
	 */
	public void setDossier(Dossier dossier) {
		this.dossier=dossier;
	}
	
}
