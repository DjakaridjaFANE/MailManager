import java.io.IOException;

import com.sun.net.httpserver.HttpServer;

public class Main {

	public static void main(String[] args) {
		BDD bdd = new BDD();
		
		HttpServer serv;
		try {
			serv = Reseau.attenteRequete(bdd);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

	}
}

/*
 * NE PAS SUPPRIMER MERCI
 * 
 * /*try {
			Compte c = new Compte("ident","mdp","nom","prenom");
			System.out.println(bdd.ajouteCompte(c));
			System.out.println(bdd.changeNom("ident","nom2", "prenom2"));
			System.out.println(bdd.ajouteAdresse(new InternetAddress("address"), "mdp", "ident"));
			System.out.println(bdd.supprimeAdresse(new InternetAddress("address"), "ident"));
			
			System.out.println(bdd.changeMDP("ident", "mdp2"));
			System.out.println(!bdd.connexion("ident", "mdp"));
			System.out.println(bdd.connexion("ident", "mdp2"));
			Mail m = new Mail(-1,new InternetAddress("testexpe"),"test objet", new Date(System.currentTimeMillis()),"content");
			m.ajouteDestinataire(new InternetAddress("dest"));
			m.ajouteCC(new InternetAddress("cc1"));
			m.ajouteCC(new InternetAddress("cc2"));
			m.ajouteCCI(new InternetAddress("cci1"));
			m.ajouteCCI(new InternetAddress("cci2"));
			m.ajouteCCI(new InternetAddress("cci3"));
			System.out.println(bdd.ajouteMail(m));
		
			
			ArrayList<Mail> mm= bdd.rechercheMail(new InternetAddress("testexpe"));
			System.out.println(mm.get(0));
			m = bdd.rechercheMail(mm.get(0).getId());
			System.out.println(m);
			System.out.println(bdd.supprimeMail(m.getId()));
			m = bdd.rechercheMail(mm.get(0).getId());
			System.out.println(m == null);
			System.out.println(bdd.rechercheCompte("ident"));
			System.out.println(bdd.supprimeCompte("ident"));
			System.out.println(bdd.rechercheCompte("ident") == null);
			
		} catch ( SQLException | AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Mail m;
		try {
			m = new Mail(-1,new InternetAddress("testexpe"),"test objet", new Date(System.currentTimeMillis()),"content");

			m.ajouteDestinataire(new InternetAddress("dest"));
			m.ajouteCC(new InternetAddress("cc1"));
			m.ajouteCC(new InternetAddress("cc2"));
			m.ajouteCCI(new InternetAddress("cci1"));
			m.ajouteCCI(new InternetAddress("cci2"));
			m.ajouteCCI(new InternetAddress("cci3"));
			System.out.println(bdd.ajouteMail(m));
			ArrayList<Address> l = new ArrayList();
			l.add(m.getDestinataire().get(0));
			ArrayList<Mail> mm= bdd.rechercheMail(null,l,null,null);
			
			System.out.println(mm);
			
			System.out.println(bdd.supprimeMail(mm.get(0).getId()));
		
			mm = bdd.rechercheMail(new InternetAddress("testexpe"),null,null,null);
			
			System.out.println(mm);
			
		} catch (AddressException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/