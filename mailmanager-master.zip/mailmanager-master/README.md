# Mail Manager

## Pourquoi ce projet ?
**MailManager** est un support permettant d'améliorer une boite mail déjà existante ou de rassembler au même endroit les mails de différentes boites mail. Il a pour but de permettre à l'utilisateur de simplifier sa gestion des mails en centralisant l'intégralité de ses mails en une seule applications. 
Cependant MailManager n'est pas une boîte mail, mais comme son nom l'indique, un outil permettant de gérer une ou des boites mails déjà existante. Cet outil permet cependant une gestion complexe des mails, leur réception et leur envoi.

## Fonctionnalités actuelles
En l'état l'application permet la réception de mail depuis les différentes boites associées au compte de l'utilisateur aisin que l'envoie de mail via l'application.

## Quel futur ?
 - réorganisation de l'interface afin de la rendre plus intuitive pour l'utilisateur lambda
 - Suppression de mails
 - Création de dossier pour une meilleure organisation de mails
 - filtrage des mails afin de les placer immédiatement dans le dossier adéquat, par exemple un mail reçu depuis une adresse catégorisée comme "profeszsionelle" serait rangé dans le dossier "pro", laissant à l'utilisateur le soin de customiser selon ses besoins les différents filtres et dossier de son compte.

## Technologies utilisées

 - PHP
 - phpMyAdmin
 - JavaMail
 - Mamp
 - MySQL
## Participants
- MARIBAS Alexandre
- BRELAUD Nathanaël
- DJAKARIDJA Fane
- BOSSE Léo
- SORIANO Bertille
- PENVEN Loris
