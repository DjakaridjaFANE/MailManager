<?php
session_start();

?>

<?php 
echo '
<style>
#titre {
display: flex;
align-items: center;
justify-content: center;
}
#icon_menu {
  float : right;
margin-right: 10%;
font-size:150%;
}
#compte {


}
#recherche_div{
margin-left:10%;
float : left;
display: inline-block;
#body {
float:right;
}

</style>
'
?>




<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8"/>
	<title>Reception</title>
</head>

<body>
	<table>
		<tr>
			<div id ="titre">
				<img src="Images/icon.png">
				<h1>MailManager</h1>
			</div>
		</tr>
		<tr>
			<div id="header">
				
				<div>
					<div id="recherche_div">
						<form id="recherche" action="valid_forms/recherche.php" method="post">
							<select multple="non">
								<option valeur="exp">Exp</option>
								<option valeur="dest">Dest</option>
								<option valeur="cc">Cc</option>
								<option valeur="cci">Cci</option>
							</select>
							<input type="text" required name="element_rechercher" size="100" />
						</form>
						<a href='ecriture.php'>Nouveau mail</a>
					</div>
					<div id="icon_menu">
						<a id="compte" href="compte.php"> 
            <img src="Images/profil.png">
            </a>
						<a href="deconnexion.php">
							<img src="Images/logout.png">
						</a>
					</div>
				</div>
			</div>
		</tr>
		<tr>
			<div id="body">
				<table>
					<tr>

						<table>
							<tr><th>Id</th><th>Expediteur</th><th>Objet</th><th>Date</th></tr>
							<?php $i = 0; foreach($_SESSION['mails'] as $valu){ foreach($valu as $v){?>
								<form id="mail" action="valid_forms/valid_mail.php">
									<td><input readonly="oui" type="text" size="5" name="id" value = <?php  echo $v['id'];?>  /></td>
									<td><input readonly="oui" type="text" size="47" name="expediteur" value = <?php  echo $v['expediteur'];?>  /></td> 
									<td><input readonly="oui" type="text" size="47" name="objet" value = <?php echo $v['objet'];?>  /></td>
									<td><input readonly="oui" type="text" size="47" name="date" value = <?php echo $v['date'];?>  /></td>
									<td>
										<input type="submit" name="reponse" form="mail" value ="Répondre"></imput>
										<input type="submit" name= "suppression" form="mail" value ="Supprimer"></input>
										<input type="submit" name= "lire" form="mail" value ="Ouvrir"></input>
									</td>
								</form>
							</tr>
						<?php }}?>
					</tr>
				</table>
			</td>
			<td>
			</tr>
		</table>
	</div>
</tr>
</table>
</body>
</html>