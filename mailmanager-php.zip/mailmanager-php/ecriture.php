<?php
session_start();

?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8"/>
<title>Nouveau mail</title>
</head>

<form action="valid_forms/envoie_mail.php" method="post" >
<body>
    Destinataires : 
    <input type="text" name="destinataires"
    value="" size="1024" />

<br>
Expediteur :  <input type="text" name="expediteur"
    value="" size="1024" />
<br>

    CCs:  <input type="text" name="ccs"
    value="" size="1024" />
<br>

    CCIs:  <input type="text" name="ccis"
    value="" size="1024" />
<br>

Objet : 
   
<input type="text" name="objet"
value= "" size="1024" />

<br>

    <textarea name="corps" rows="8" cols="32">
    Saisissez votre texte ici...
    </textarea>

<br>

    <input type="submit" name="envoi"
    value="Envoi" />

</form>
<a href='reception.php'>Retour à la reception</a>