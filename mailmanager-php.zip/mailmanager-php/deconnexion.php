<?php
session_start();
$nom =  $_SESSION['nom'];
$prenom =$_SESSION['prenom'];
session_destroy();

?>

<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8"/>
	<title>Reception</title>
</head>

<body>
    <div id="body">
    <h1>Bonne journée</h1>
    <h2><?php echo $nom . " " . $prenom ?></h2>
</div>
</body>
</html>

<?php 
echo '
<style>
#body {
    margin-left: auto;
  margin-right: auto;
  width: 25%;
}
</style>
'
?>