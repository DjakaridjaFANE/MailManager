<?php

    session_start();
    $_SESSION['Connect']=false;
?>
<!------ HTML ------->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAILMANAGER</title>
</head>
<body>
<!------ CSS ------->
<?php 
echo '
<style>
#connection { margin-left: auto;
    margin-right: auto;
    width: 20%;
    border:solid 2px black;
}
#titre {
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>
'
?>
    <div id="connection">
    <div id ="titre">
    <img src="Images/icon.png">
    <h1>MailManager</h1>
    </div>
    <div><h4> CONNEXION</h4></div>
    <!------ formulaire de connection ------->
    <form action="valid_forms/valid_connexion.php" method="post">
        <table>  
            <tr><td>identifiant : </td><td><input type="text" required name="identifiant" size="20" /></td></tr>
            <tr><td>Mot de passe : </td><td><input type="password" name="password" required minlength="4" size="20" /></td></tr>
            <?php echo "<tr><td>". $_SESSION['erreur'] ."</td></tr>"; ?>
            <tr><td><button type="submit" name="valider"><em>SE CONNECTER</em></button></td></tr>
        </table>
    </form>
    <p>Si vous n'avez pas créé de compte, veuillez en créer un en cliquant <a href="inscription.php">ici</a> .</p>
</div>
</body>
</html>

