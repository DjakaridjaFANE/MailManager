<?php
session_start();
echo $_SESSION['compte'];
require('deconnexion.php');

?>

<!-- Css -->
<?php echo "
<style>
#info_compte {
    margin-left: auto;
    margin-right: auto;
    width: 50%;
}
</style>
";
?>



<!-- HTML  -->
<!DOCTYPE HTML> 
<html>
<head>
<meta charset="UTF-8"/>
<title>Compte</title>
</head>
<body>
<?php if ($_SESSION['Connect'] == true)
{
?>
<div id="info_compte">
    <h2>Information du Compte</h2>
<table>
    <form action="valid_forms/modif_compte.php" method="post" id="modifCompte">
    <tr><td>Nom : </td><td><input type="text" required name="nom" value = <?php echo $_SESSION['nom'];?> size="100" /></td></tr> 
    <tr><td>Prénom : </td><td><input type="text" required name="prenom" value = <?php echo $_SESSION['prenom']; ?> size="100" /></td></tr>
    <tr><td>Identifiant : </td><td><input type="text" required name="identifiant" value = <?php echo $_SESSION['identifiant']; ?> size="100" /></td></tr>
    <tr><td>Mot de passe : </td><td><input type="text" required name="mot_de_passe" value = <?php echo $_SESSION['mdp']; ?> size="100" /></td></tr>
    <tr>
      
    <td>Adresses : </td>
    <td>
        <table>
            <?php $i = 0; foreach($_SESSION['adresses'] as $valu){ ?>
           <tr><td><input type="text" name=<?php echo "adresse" +$i ;?> value = <?php  echo $valu['adresse'];?> size="47" /></td> 
            <td><input type="text" name=<?php echo "mdp" +$i ;?> value = <?php echo $valu['mdp']; ?> size="47" /></td></tr>
            <?php $i++;}?>
            <tr>
                <td><input type="text" name="newmail" size="47" /> </td>
                <td><input type="text" name="newmdp" size="47" /> </td>
                <td><input type="submit" name="ajoute_adresse" form="modifCompte" value ="Ajouter"></imput></td>
                <td><input type="submit" name="supprime_adresse" form="modifCompte" value ="Supprimer"></imput></td>
            </tr>
        </table>
    </td> 
    <tr><td><input type="submit" name="valider" form="modifCompte" value ="Valider"></imput></form>
    

</table>
<a href="reception.php"> Réception</a>
    </div>

</html>
<?php 
}
else
{
    header("Location: connexion.php");
    exit();
}
?>