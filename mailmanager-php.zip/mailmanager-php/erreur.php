<?php session_start(); ?>

<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8"/>
<title>Erreur</title>
</head>

<body>
    <h1>Erreur</h1>
    <p><?php echo $_SESSION['erreur'];?></p>
</body>
</html>