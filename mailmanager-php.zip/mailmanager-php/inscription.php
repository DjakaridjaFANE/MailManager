<?php
session_start();
$_SESSION['Connect']=false;
session_destroy(); 
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAILMANAGER</title>
</head>
<body>
<?php echo "<h1> BIENVENUE SUR MAILMANAGER !</h1>"; ?><br><br>
    <p>Le site qui vous permet la gestion de vos mails.<br>
       Si vous avez déja un compte <a href="connexion.php">connectez-vous!</a> </p>
        <div><h4>INSCRIPTION</h4></div>
    <form action="valid_forms/valid_inscription.php" method="post">
        <table>
        <tr><td>Identifiant : </td><td><input type="text" required name="identifiant" size="20" /></td></tr> 
            <tr><td>Nom : </td><td><input type="text" required name="nom" size="20" /></td></tr> 
            <tr><td>Prénom : </td><td><input type="text" required name="prenom" size="20" /></td></tr>
            <tr><td>adresse email : </td><td><input type="email" required name="email" size="40"/><td>mot de passe du compte : </td><td><input type="text" required name="mdp_email" size="100"/></td></tr>
            <tr><td>Mot de passe : </td><td><input type="password" required name="mot_de_passe" required minlength="10" maxlength="20" size="20"/></td></tr>
            <tr><td>Confirmation de mot de passe : </td><td><input type="password" required name="Confirmation de mot de passe" size="20"/></td></tr>
            <tr><td><button type="submit" name="valider" ><em>S'INSCRIRE</em></button></td></tr>
        
        </table>
    </form>
</body>
</html>