<?php
session_start();
foreach($_SESSION['mails'] as $valu){
    foreach($valu as $v){
        
        if(strcmp($v['id'], $_SESSION['mail_id'])==0){
            $encode = $v;
        }
    }
}
$ch = curl_init();

$url = "127.0.0.1:8000/mailmanager/mail?identifiant:" . $_SESSION['identifiant']  ."&mdp:" . $_SESSION['mdp'];
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE"); 
    echo json_encode($encode);                                                                  
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($encode));                                                                  
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $retour = (string) curl_exec( $ch );
    curl_close($ch);
    if (strpos($retour , "erreur") != false) {
        $erreur = json_decode($retour);
        $_SESSION['erreur'] = $erreur['erreur'];
        header('Location: '.'http://localhost/projet/erreur.php');   
        exit();
    } 
    include("valid_reception.php");

?>