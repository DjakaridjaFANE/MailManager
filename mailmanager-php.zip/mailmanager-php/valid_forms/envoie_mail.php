<?php
session_start();
$destinataire = explode(" ", $_POST['destinataires']);
$cc = explode(" ", $_POST['ccs']);
$cci = explode(" ", $_POST['ccis']);
$objet =  $_POST['objet'];
$contenu = $_POST['corps'];
$expediteur = $_POST['expediteur'];
$json = "{\"mails\":{\"destinataire\":[";
$i = 0;
$count = count($destinataire);
foreach($destinataire as $dest){
	if(strcmp($dest , "") !== 0){
		if($count !== $count )
			$json .= "\"" . $dest . "\",";
		else
			$json .= "\"" . $dest . "\"";
		$i++;
	}
}

$json .= "],\"cc\":[";
$i = 0;
$count = count($cc);
foreach($cc as $c){
	if(strcmp($dest , "") !== 0){
		if($count !== $count )
			$json .= "\"" . $c . "\",";
		else
			$json .= "\"" . $c . "\"";
		$i++;
	}
}

$json .= "],\"cci\":[";
$i = 0;
$count = count($cci);

foreach($cci as $c){
	if(strcmp($dest , "") !== 0){
        echo strcmp($dest , "");
		if($count !== $count )
			$json .= "\"" . $c . "\",";
		else
			$json .= "\"" . $c . "\"";
		$i++;
	}
}

$json .= "],\"expediteur\":\"" . $expediteur . "\",\"objet\":\"" . $objet . "\",\"contenu\":\"" . $contenu . "\",\"piecesJointes\":[]}}";

$url = "127.0.0.1:8000/mailmanager/mail?identifiant:" . $_SESSION['identifiant']  ."&mdp:" . $_SESSION['mdp'];
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $retour = (string) curl_exec( $ch );
    curl_close($ch);
    if (strpos($retour , "erreur") != false) {
        $erreur = json_decode($retour);
        $_SESSION['erreur'] = $erreur['erreur'];
        header('Location: '.'http://localhost/projet/erreur.php');   
        exit();
    } 
    header('Location: '.'http://localhost/projet/reception.php');   
    exit();
?>