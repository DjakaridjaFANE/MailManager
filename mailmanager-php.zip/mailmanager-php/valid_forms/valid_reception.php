<?php   
        session_start();
         $ch = curl_init();
         $identifiant = $_SESSION['identifiant'];
         $mdp = $_SESSION['token'];

         

         try {
                $url = "127.0.0.1:8000/mailmanager/mails?identifiant:" . $identifiant . "&mdp:" . $mdp;
                curl_setopt($ch, CURLOPT_URL,$url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HEADER, false);
               
                $retour = (string) curl_exec( $ch );
                curl_close($ch);
                if (strpos($retour , "erreur") != false) {
                    $erreur = json_decode($retour);
                    $_SESSION['erreur'] = $erreur['erreur'];
                    header('Location: '.'http://localhost/projet/erreur.php');   
                    exit();
                }
                
                unset($_SESSION['mails']);
                $_SESSION['mails'] =json_decode( $retour , true);         
                header('Location: '.'http://localhost/projet/reception.php');
                exit();
                
            } catch (\Throwable $th) {
                throw $th;
            } finally {
                curl_close($ch);
            }
?>