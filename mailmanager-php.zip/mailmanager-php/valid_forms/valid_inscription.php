<?php
session_start();
$ch = curl_init();
    
$identifiant= $_POST['identifiant'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$motdepasse = $_POST['mot_de_passe'];
$adresses =$_POST['email'];
$mdp_email = $_POST['mdp_email'];

$adressestring ="[";
$adressestring = $adressestring . "{\"adresse\":\"" . $adresses . "\",\"mdp\":\"" . $mdp_email . "\"}";
$adressestring = $adressestring ."]";

$datas = array("identifiant"=>$identifiant,"nom"=>$nom , "prenom"=>$prenom, "mdp"=>$motdepasse, "adresses"=>$adressestring);
$dataString = "{";
$i =0;
$count = count($datas);
foreach($datas as $key=>$value) {
    if($i !== $count -1 )
        $dataString =  $dataString ."\"" . $key . "\"" . ":" . "\"" . $value . "\"" .",";
    else
    $dataString =  $dataString ."\"" . $key . "\"" . ":" . $value .",";
    $i++;
}
$dataString = substr( $dataString, 0, -1);
$dataString .= "}";



$url = "127.0.0.1:8000/mailmanager/compte?identifiant:" . $_SESSION['identifiant']  ."&mdp:" . $_SESSION['mdp'];
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

echo $dataString;
$retour = (string) curl_exec( $ch );
curl_close($ch);
if ( strpos($retour , "erreur") != false) {
    $erreur = json_decode($retour);
    $_SESSION['erreur'] = $erreur['erreur'];
    header('Location: '.'http://localhost/projet/erreur.php');   
    exit();
}
else {
header('Location: '.'http://localhost/projet/reception.php');   
exit();
}

?>