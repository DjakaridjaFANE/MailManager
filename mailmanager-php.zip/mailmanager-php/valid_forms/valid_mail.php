<?php
session_start();

if(strcmp($_GET['reponse'] , "Répondre") == 0){
    $_SESSION['mail_id'] = $_GET['id'];
    header('Location: '.'http://localhost/projet/ecriture.php');
    exit();
}
else if(strcmp($_GET['suppression'] , "Supprimer") == 0){
    $_SESSION['mail_id'] = $_GET['id'];
    include('supprimer_mail.php');
}
else if(strcmp($_GET['lire'] , "Ouvrir") == 0){
    $_SESSION['mail_id'] = $_GET['id'];
    header('Location: '.'http://localhost/projet/lecture.php');
    exit();
}
?>