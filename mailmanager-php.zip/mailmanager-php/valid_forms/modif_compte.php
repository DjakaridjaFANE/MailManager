<?php
session_start();

    if(strcmp($_POST['valider'] , "Valider") == 0) {
    $ch = curl_init();
    
    $identifiantModifier = $_POST['identifiant'];
    $nomModifier = $_POST['nom'];
    $prenomModifier = $_POST['prenom'];
    $motdepasseModifier = $_POST['mot_de_passe'];
    $adressesModifier =$_SESSION['adresses'];
    $adressestring ="[";
    $i = 0;
    
    $count = count($_SESSION['adresses']);
   
    foreach($adressesModifier as $adresse){
        if($i !== $count -1)
            $adressestring = $adressestring . "{\"adresse\":\"" . $adresse['adresse'] . "\",\"mdp\":\"" . $adresse['mdp'] . "\"},";
        else
            $adressestring = $adressestring . "{\"adresse\":\"" . $adresse['adresse'] . "\",\"mdp\":\"" . $adresse['mdp'] . "\"}";
        $i++;
    }
    $adressestring = $adressestring ."]";
    
    $datas = array("identifiant"=>$identifiantModifier,"nom"=>$nomModifier , "prenom"=>$prenomModifier, "mdp"=>$motdepasseModifier, "adresses"=>$adressestring);
    $dataString = "{";
    $i =0;
    $count = count($datas);
    foreach($datas as $key=>$value) {
        if($i !== $count -1 )
            $dataString =  $dataString ."\"" . $key . "\"" . ":" . "\"" . $value . "\"" .",";
        else
        $dataString =  $dataString ."\"" . $key . "\"" . ":" . $value .",";
        $i++;
    }
    $dataString = substr( $dataString, 0, -1);
    $dataString .= "}";
    $url = "127.0.0.1:8000/mailmanager/compte?identifiant:" . $_SESSION['identifiant']  ."&mdp:" . $_SESSION['mdp'];
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $retour = (string) curl_exec( $ch );
    curl_close($ch);
   
    if ( strpos($retour , "erreur") != false) {
        $erreur = json_decode($retour);
        $_SESSION['erreur'] = $erreur['erreur'];
        header('Location: '.'http://localhost/projet/erreur.php');   
        exit();
    } 
    
    header('Location: '.'http://localhost/projet/reception.php');   
    exit();
    
}
else if(strcmp($_POST['ajoute_adresse'] , "Ajouter") == 0){
        $tab_adresse['adresse'] = $_POST['newmail'];
        $tab_adresse['mdp'] = $_POST['newmdp'];
        $_SESSION['adresses'][] =  $tab_adresse;
        header('Location: '.'http://localhost/projet/compte.php');
        exit();
}
else if(strcmp($_POST['supprime_adresse'] , "Supprimer") == 0){
    $tab = $_SESSION['adresses'];
    $i = 0;
    foreach($_SESSION['adresses'] as $adresse){          
        if(strcmp($adresse['adresse'], $_POST['newmail']) == 0){  
            echo $adresse['adresse'] . " " . $_POST['newmail'] . " ". strcmp($adresse['adresse'], $_POST['newmail']);     
            array_splice($_SESSION['adresses'],$i, 1 );
        }
        $i++;
    }
    header('Location: '.'http://localhost/projet/compte.php');
    exit();
}
?>