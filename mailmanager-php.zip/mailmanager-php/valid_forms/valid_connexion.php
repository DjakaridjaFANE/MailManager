<?php

    session_start();
    $ch = curl_init();
    $identifiant = $_POST['identifiant'];
    $mdp = $_POST['password'];
    $_SESSION['identifiant'] = $identifiant;
    $_SESSION['mdp'] = $mdp;
    
    
try {
    
    $url = "127.0.0.1:8000/mailmanager/compte?identifiant:" . $identifiant . "&mdp:" . $mdp;
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 50);   
	curl_setopt($ch, CURLOPT_TIMEOUT, 50);
   
    $retour = (string) curl_exec( $ch );
    curl_close($ch);
    if ( strpos($retour , "erreur") != false) {
       $erreur = json_decode($retour, true );
        $_SESSION['erreur'] = $erreur['erreur'];
        if(strcmp( $erreur['type'] , "Not Fatal") == 0) {
        header('Location: '.'http://localhost/projet/connexion.php');   
        exit();
        }
        else {
        header('Location: '.'http://localhost/projet/erreur.php');   
        exit();
        }
    }
    else {
    unset( $_SESSION['erreur']);
    unset($_SESSION['identifiant']);
    unset($_SESSION['token']);
    unset($_SESSION['nom']);
    unset($_SESSION['prenom']);
    unset($_SESSION['adresses']);
    unset($_SESSION['Connect']);
    $json = json_decode($retour , true);
    $_SESSION['erreur'] = "";
    $_SESSION['identifiant'] = $json['identifiant'];
    $_SESSION['token'] = $json['mdp'];
    $_SESSION['nom'] = $json['nom'];
    $_SESSION['prenom'] = $json['prenom'];
    $_SESSION['adresses'] = $json['adresses'];
    $_SESSION['Connect'] = true;    
    include('valid_reception.php');
    }
    
} catch (\Throwable $th) {
    throw $th;
} finally {
    curl_close($ch);
}
?>
