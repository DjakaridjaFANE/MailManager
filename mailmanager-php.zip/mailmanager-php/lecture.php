<?php 
session_start();
foreach($_SESSION['mails'] as $valu){
    foreach($valu as $v){
        
        if(strcmp($v['id'], $_SESSION['mail_id'])==0){
            $expediteur = $v['expediteur'];
            $date = $v['date'];
            $objet =$v['objet'];
            $contenu =$v['contenu'];
            $destinataire;
            foreach($v['destinataire'] as $des){
                $destinataire .=" " . $des;
            }
            $cc;
            foreach($v['cc'] as $c){
                $cc .=" " . $c;
            }
            $cci;
            foreach($v['cci'] as $ci){
                $cci .=" " . $ci;
            }
            
        }
    }
}
?>

<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8"/>
	<title>Lecture</title>
</head>

<body>

<table>
			<tr>
            <div id ="titre">
			<img src="Images/icon.png">
			<h1>MailManager</h1>
		</div>
        </tr>
        <tr><td>Date :</td><td><?php echo $date; ?></td></tr>
        <tr><td>Expediteur :</td><td><?php echo $expediteur; ?></td></tr>
        <tr><td>Destinataire :</td><td><?php echo $destinataire; ?></td></tr> 
        <tr><td>Cc :</td><td><?php echo $cc; ?></td></tr>
        <tr><td>Cci :</td><td><?php echo $cci; ?></td></tr>
        <tr><td>Objet :</td><td><?php echo $objet; ?></td></tr>
        <tr><td>Pieces Jointes :</td><?php ?><td></td></tr>
        <tr><td>Contenu :</td><td><?php echo $contenu; ?></td></tr>   
</table>
<a href="reception.php"> Réception</a>
</body>
</html>

<?php 
echo '
<style>
#titre {
display: flex;
align-items: center;
justify-content: center;
}
';?>

